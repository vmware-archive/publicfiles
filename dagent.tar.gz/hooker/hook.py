#!/usr/bin/env python3

from plumbum import cli
from plumbum import local
from log import log


class HookLocationDoesNotExist(Exception):
    pass


class HookDoesNotExist(Exception):
    pass


class Hooker(cli.Application):
    pass


class UnsupportedProjectType(Exception):
    pass


def _detect(directory):
    import project_types
    for project_type in project_types.supported_types:
        project_description = project_type.detect(directory)
        if project_description:
            log.debug('Detected project %s', project_description)
            return project_description
    
    return None


@Hooker.subcommand("detect")
class detect(cli.Application):
    """Detect the project type residing in the current directory"""
    def main(self, directory):
        project_description = _detect(directory)
        if project_description:
            with log.indented('Detected project at %s' % directory):
                log.info('Project type: %s', project_description.type)


@Hooker.subcommand("hook")
class hook(cli.Application):
    """Hook the project residing in the directory specified"""
    def main(self, directory, environment_conf=""):
        hook_directory = local.path('..')
        project_description = _detect(directory)
        if not project_description:
            raise UnsupportedProjectType(directory)

        log.info('Detected project suitable for hooking %s', project_description)
        project_description.hooker(project_description, hook_directory, environment_conf)


if __name__ == "__main__":
    Hooker.run()
