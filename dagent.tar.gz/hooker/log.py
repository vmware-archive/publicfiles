from log_config import configure
configure()
import logging

log = logging.getLogger('hooker')
log.setLevel(logging.DEBUG)

