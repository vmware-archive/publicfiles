from easypy.bunch import Bunch


class ProjectDescription(Bunch):
    KEYS = frozenset(['base_path', 'type', 'name', 'version', 'hooker'])


class Base(object):
    def detect(self):
        raise NotImplemented()

    def hook(self):
        raise NotImplemented()