from . import node_js

supported_types = [node_js.NodeJS]