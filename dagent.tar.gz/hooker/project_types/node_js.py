from .base import Base, ProjectDescription
from plumbum import local
from os import path
import sys
from easypy.bunch import Bunch
from easypy.exceptions import TException
import json


class ProjectIsNotNodeJS(Exception):
    pass


class ProjectIsAlreadyHooked(Exception):
    pass


class UnknownEntryPoint(Exception):
    pass


class CannotFindEntrypointDirectory(Exception):
    pass


class PackageJsonHasNoStart(TException):
    template = "Target package.json is missing scripts[\"start\"]"


class NodeJS(Base):
    HOOK_SCRIPT_NAME = 'octarine_hook.js'
    _dependencies = {
        'ffi': '^2.2.0',
        'exit-hook': '^1.1.1',
        'ref': '^1.3.4',
        'ref-array': '^1.2.0'}

    @classmethod
    def detect(cls, directory='.'):
        directory = local.path(directory)
        try:
            package = cls._json(directory)
        except OSError:
            return False

        return ProjectDescription(base_path=directory, type='nodejs', 
                                  name=package['name'], version=package['version'], hooker=cls.hook)

    @classmethod
    def _json(cls, path):
        package_path = path / 'package.json'
        return json.load(open(str(package_path)))

    @classmethod
    def _write_json(cls, path, _json):
        package_file = open(str(path / 'package.json'), 'w')
        json.dump(_json, package_file, indent=4, sort_keys=True)

    @classmethod
    def _find_entrypoint(cls, base_path, start_script):
        estimated_entrypoint_index = None
        entrypoint = None
        for i, element in enumerate(start_script):
            if element.endswith('.js'):
                estimated_entrypoint_index = i
                break

        if estimated_entrypoint_index is None:
            return entrypoint, estimated_entrypoint_index

        entrypoint = start_script[estimated_entrypoint_index]
        entrypoint_directory = local.path(base_path / entrypoint).dirname
        if not entrypoint_directory.exists():
            raise CannotFindEntrypointDirectory(entrypoint_directory)

        return entrypoint, estimated_entrypoint_index

    @classmethod
    def _start_script(cls, base_path):
        json = cls._json(base_path)
        if 'start' not in json['scripts']:
            return ['node', 'server.js']

        start_script = json['scripts']['start']
        split_start = start_script.split()

        return split_start

    @classmethod
    def is_hooked(cls, base_path):
        start_script = cls._start_script(base_path)
        entrypoint, entrypoint_index = cls._find_entrypoint(base_path, start_script)
        return path.basename(entrypoint) == cls.HOOK_SCRIPT_NAME

    @classmethod
    def _hook_entry_point(cls, base_path, json, environment_conf):
        from os import path
        if 'start' not in json['scripts']:
            start_script = ['node', 'server.js']
        else:
            start_script = json['scripts']['start'].split()

        entrypoint, estimated_entrypoint_index = cls._find_entrypoint(base_path, start_script)
        if not entrypoint:
            raise UnknownEntryPoint(start_script)

        new_entrypoint = path.join(path.dirname(entrypoint), cls.HOOK_SCRIPT_NAME)
        start_script.insert(estimated_entrypoint_index, str(new_entrypoint))
        json['scripts']['start'] = environment_conf + ' ' + ' '.join(start_script)

        return base_path / new_entrypoint, entrypoint

    @classmethod
    def _copy_artifacts(cls, destination_path, hook_path, entrypoint_path):
        artifacts_dir = hook_path / 'build'
        if sys.platform == 'darwin':
            suffix_glob = '*.dylib'
        else:
            suffix_glob = '*.so'

        for artifact in artifacts_dir.glob(suffix_glob):
            artifact.copy(destination_path / artifact.basename)

        (hook_path / 'hooks' / 'node-js' / cls.HOOK_SCRIPT_NAME).copy(entrypoint_path)

    @classmethod
    def _fixup_hook(cls, hooked_entrypoint_path, original_entrypoint_basename):
        hook_contents = open(hooked_entrypoint_path).read()
        hook_contents += "\n\nrequire('./%s')\n" % (original_entrypoint_basename,)
        open(hooked_entrypoint_path, 'w').write(hook_contents)

    @classmethod
    def _add_dependencies(cls, base_path, json):
        json['dependencies'].update(cls._dependencies)

    @classmethod
    def hook(cls, project_description, hook_path, environment_conf):
        base_path = project_description.base_path
        _json = cls._json(base_path)
        if not cls.detect(base_path):
            raise ProjectIsNotNodeJS(base_path)

        if cls.is_hooked(base_path):
            raise ProjectIsAlreadyHooked(base_path)

        hooked_entrypoint_path, original_entrypoint_basename = cls._hook_entry_point(base_path, _json, environment_conf)
        cls._add_dependencies(base_path, _json)
        cls._copy_artifacts(base_path, hook_path, hooked_entrypoint_path)
        cls._fixup_hook(str(hooked_entrypoint_path), original_entrypoint_basename)
        cls._write_json(base_path, _json)
