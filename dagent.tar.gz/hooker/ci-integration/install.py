#!/usr/bin/env python3
from plumbum import local
from plumbum import cli
 
configuration_template = {'OCTARINE_SERVICE_ARTIFACT' : 'bla:bla',
        'OCTARINE_SERVICE_DEPLOYMENT' : 'bla:bla',
        'OCTARINE_MAMESPACE' : 'demo',
        'OCTARINE_artifact_name' : 'foo',
        'OCTARINE_SERVICE_VERSION' : '1.0',
        'OCTARINE_KAFKA_HOSTNAME' : 'localhost',
        'OCTARINE_KAFKA_PORT' : 5050,
        'OCTARINE_BACKEND_HOSTNAME' : 'localhost',
        'OCTARINE_BACKEND_USERNAME' : 'FILLME',
        'OCTARINE_BACKEND_PASSWORD' : 'FILLME',
        'OCTARINE_BACKEND_LOGIN_PORT': 8070,
        'OCTARINE_BACKEND_CONFIG_PORT': 8080
}

def _get_conf(namespace, artifact_name):
    conf = configuration_template.copy()
    conf['OCTARINE_SERVICE_ARTIFACT'] = artifact_name
    conf['OCTARINE_SERVICE_DEPLOYMENT'] = artifact_name
    env = []
    for key, value in conf.items():
        env.append('%s="${%s:-%s}"' % (key, key, value))

    return ' '.join(env)

def _get_latest_agent_version():
    return (local['s3cmd']['ls', 's3://dagent-products'] | local['sort'] | local['tail']['-1'])().split()[-1].strip()

def _download_artifacts(agent_version):
    import tempfile

    if agent_version != 'latest':
        filename = 's3://dagent-products/dagent_%s.tar.gz' % (agent_version,)
    else:
        filename = _get_latest_agent_version()
    
    print('Downloading %s ...' % (filename,))
    target = tempfile.mktemp()
    target_dir = tempfile.mkdtemp()

    local["s3cmd"]('get', filename, target)
    local["tar"]('-zxf', target, '-C', target_dir)
    print('Extracted download to %s' % (target_dir,))
    return target_dir

def _run_downloaded_installer(path, namespace, artifact_name, project_directory):
    with local.cwd(path + '/hooker/ci-integration'):
        local['./install.py'](namespace, artifact_name, project_directory)

    return 0

class install(cli.Application):
    """Hook the project residing in the directory specified"""
    def _hook(self, namespace, artifact_name, project_directory):
        conf = _get_conf(namespace, artifact_name)
        with local.cwd('../'):
            local['./hook.py']('hook', project_directory, conf)
            return 0

    def main(self, namespace, artifact_name, project_directory, agent_version=''):
        import os
        project_directory = os.path.abspath(project_directory)
        if not agent_version:
            return self._hook(namespace, artifact_name, project_directory)
        else:
            target_dir = _download_artifacts(agent_version)
            return _run_downloaded_installer(target_dir, namespace, artifact_name, project_directory)


if __name__ == "__main__":
    install.run()