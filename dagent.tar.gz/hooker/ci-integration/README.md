install.py
============

installer.py integrates the Octarine agent and its configuration into the building of a container. install.py is meant to be called from the CI build script (e.g., from .travis.yml). Its requirements are specified in requirements.txt. It's pretty simple, and the following examples will get you familiarized with its operation. install.py must be run from the ci-integration directory.

Hook Octarine into an existing project. Use local Octarine artficts rather than download them from S3. This will use the Octarine configuration (backend address, username, password, kafka host, key path) associated with the namespace/artifact_name pair.
```sh
./install.py test bla:bla ../../ut/loopback_service
```

Perform the same as above, but use the latest Octarine agent from S3 instead of any local files:
```sh
./install.py test bla:bla ../../ut/loopback_service latest
```

Perform the same as above, but use the Octarine agent with the version 82d430c from S3 instead of any local files:
```sh
./install.py test bla:bla ../../ut/loopback_service 82d430c
```

After running the installer, the project's package.json should look a little like this:
```json
{
    "author": "",
    "dependencies": {
        "exit-hook": "^1.1.1",
        "express": "^4.15.4",
        "ffi": "^2.2.0",
        "ref": "^1.3.4",
        "ref-array": "^1.2.0",
        "sync-request": "^4.1.0"
    },
    "description": "",
    "license": "ISC",
    "main": "server.js",
    "name": "loopback_service",
    "scripts": {
        "start": "OCTARINE_SERVICE_ARTIFACT=\"${OCTARINE_SERVICE_ARTIFACT:-bla:bla}\" OCTARINE_SERVICE_DEPLOYMENT=\"${OCTARINE_SERVICE_DEPLOYMENT:-bla:bla}\" OCTARINE_MAMESPACE=\"${OCTARINE_MAMESPACE:-demo}\" OCTARINE_artifact_name=\"${OCTARINE_artifact_name:-foo}\" OCTARINE_SERVICE_VERSION=\"${OCTARINE_SERVICE_VERSION:-1.0}\" OCTARINE_KAFKA_HOSTNAME=\"${OCTARINE_KAFKA_HOSTNAME:-localhost}\" OCTARINE_KAFKA_PORT=\"${OCTARINE_KAFKA_PORT:-5050}\" OCTARINE_BACKEND_HOSTNAME=\"${OCTARINE_BACKEND_HOSTNAME:-localhost}\" OCTARINE_BACKEND_USERNAME=\"${OCTARINE_BACKEND_USERNAME:-FILLME}\" OCTARINE_BACKEND_PASSWORD=\"${OCTARINE_BACKEND_PASSWORD:-FILLME}\" OCTARINE_BACKEND_LOGIN_PORT=\"${OCTARINE_BACKEND_LOGIN_PORT:-8070}\" OCTARINE_BACKEND_CONFIG_PORT=\"${OCTARINE_BACKEND_CONFIG_PORT:-8080}\" node octarine_hook.js server.js"
    },
    "version": "1.0.0"
}
```

Note that the configuration is passed to node through environment variables specified in the commandline. The syntax used ensures that if environment variables with the same names are passed from the existing environment, they will override the default configuration

hook.sh
===============

The hook.sh can be inserted into a user's build process to pull the public version of the dagent and hook their project. Usually they would download and run the script as follows:
```bash
curl -sL https://github.com/octarinesec/publicfiles/raw/master/hook.sh | bash -s -- $(pwd)/node_server
```

The full path of the project must be provided as an argument. 