from _socket import gethostname
import warnings
import logging
import logging.config
import os
from pathlib import Path

from easypy import logging as easypy_logging
import socket
HOSTNAME = socket.gethostname()
LOG_PATH = os.environ.get('LOG_PATH', '')

logging.addLevelName(logging.WARN, "WARN")  # instead of "WARNING", so that it takes less space...
logging.addLevelName(logging.NOTSET, "NA")  # instead of "NOTSET", so that it takes less space...
if not issubclass(logging.Logger, easypy_logging.ContextLoggerMixin):
    logging.Logger.__bases__ = logging.Logger.__bases__ + (easypy_logging.ContextLoggerMixin,)


MAIN_LOG_FILE = os.path.join(LOG_PATH, 'teka.log')

if os.getenv('TERM_LOG_STDOUT'):
    console_stream = 'stdout'
else:
    console_stream = 'stderr'

CONFIG = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'detailed': {
            'format': '%(asctime)s|%(process)2s:%(threadName)-25s|%(name)-40s|%(levelname)-5s|%(funcName)-30s |%(host)-35s|%(context)s%(message)s',
        },
        'failures': {
            'format': '%(asctime)s|%(threadName)-25s|%(name)-5s|%(funcName)-30s |%(host)-35s|%(context)s%(message)s',
        },
        'autosync': {
            '()': 'easypy.logging.ConsoleFormatter',
            'format': '%(asctime)s|%(context)s%(message)s',
        },
        'console': {
            '()': 'easypy.logging.ConsoleFormatter',
            'fmt': '%(levelcolor)s<<%(asctime)s|%(levelname)-5s|%(host)-25s>>|'
                   '%(drawing)s%(message)s',
            'datefmt': '%H:%M:%S'
        },
        'yaml': {
            '()': 'easypy.logging.YAMLFormatter',
            'allow_unicode': True,
            'explicit_start': True,
            'explicit_end': True,
            'encoding': 'utf-8',
        },
    },
    'handlers': {
        'context': {
            'class': 'easypy.logging.ContextHandler',
            'host': HOSTNAME,  # this should be something less specific, like 'realm', 'place'

        },
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': "console",  # if sys.stdout.isatty() else "detailed",
            'level': 'INFO',
            'stream': 'ext://sys.%s' % console_stream
        },
        'main_file': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': MAIN_LOG_FILE,
            'mode': 'w',
            'formatter': 'detailed',
            'level': 'DEBUG',
            'maxBytes': 2**20 * 50,
            'backupCount': 1,
            'delay': True,
        },
        'aux': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': os.path.join(LOG_PATH, 'aux.log'),
            'mode': 'w',
            'formatter': 'detailed',
            'level': 'DEBUG',
            'maxBytes': 2**20 * 50,
            'backupCount': 1,
            'delay': True,
        },
        'autosync': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': os.path.join(LOG_PATH, 'autosync.log'),
            'mode': 'w',
            'formatter': 'autosync',
            'level': 'DEBUG',
            'maxBytes': 2**20 * 50,
            'backupCount': 1,
            'delay': False,
        },
        'failures': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': os.path.join(LOG_PATH, 'failures.log'),
            'mode': 'w',
            'formatter': 'failures',
            'level': 'DEBUG',
            'maxBytes': 2**20 * 50,
            'backupCount': 1,
            'delay': False,
        },
        'boto': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': os.path.join(LOG_PATH, 'boto.log'),
            'mode': 'w',
            'formatter': 'detailed',
            'level': 'DEBUG',
            'maxBytes': 2**20 * 50,
            'backupCount': 1,
            'delay': True,
        },
        'threads': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': os.path.join(LOG_PATH, 'threads.yaml.log'),
            'mode': 'w',
            'formatter': 'yaml',
            'level': 'DEBUG',
            'maxBytes': 2**20 * 50,
            'backupCount': 1,
            'delay': True,
        },
        'evidences': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': os.path.join(LOG_PATH, 'evidences.yaml.log'),
            'mode': 'w',
            'formatter': 'yaml',
            'level': 'DEBUG',
            'maxBytes': 2**20 * 50,
            'backupCount': 1,
            'delay': True,
        },
        'metrics': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': os.path.join(LOG_PATH, 'metrics.yaml.log'),
            'mode': 'w',
            'formatter': 'yaml',
            'level': 'DEBUG',
            'maxBytes': 2**20 * 100,
            'backupCount': 5,
            'delay': True,
        },
        'viewer': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': os.path.join(LOG_PATH, 'viewer.log'),
            'mode': 'w',
            'formatter': 'detailed',
            'level': 'DEBUG',
            'maxBytes': 2**20 * 1,
            'backupCount': 1,
            'delay': True,
        },
        'progress' : {
            'class': 'easypy.logging.ProgressHandler',
        },
    },
    'root': {
        'level': 'NOTSET',
        'handlers': ['context', 'console', 'main_file', 'progress']
    },
    'loggers': {
        'threads': {
            'propagate': False,
            'handlers': ['context', 'threads']
        },
        'metrics': {
            'propagate': False,
            'handlers': ['metrics']
        },
        'viewer': {
            'propagate': False,
            'handlers': ['context', 'console', 'viewer']
        },
        'failures': {
            'propagate': False,
            'handlers': ['context', 'failures']
        },
        'autosync': {
            'propagate': False,
            'handlers': ['context', 'autosync']
        },
        'evidences': {
            'propagate': False,
            'handlers': ['evidences']
        }

    }
}

BOTO_LOGGERS = ['boto', 'boto3', 'botocore']
SILENCED_LOGGERS = [
    'paramiko', 'paramiko.transport', 'plumbum.shell', 'sentry.errors',
    'urllib3.connectionpool', 'aux', 'requests.packages.urllib3.connectionpool', 'talker.debug']

CONFIG['loggers'].update((name, dict(propagate=False, handlers=['console', 'context', 'aux', 'progress'])) for name in SILENCED_LOGGERS)

def supress_graylog():
    pass


def set_main_filename(filename):
    global MAIN_LOG_FILE
    logfile = Path(filename)
    if not logfile.is_absolute():
        logfile = Path(str(LOG_PATH)) / logfile
    handler = logging._handlers['main_file']
    handler.baseFilename = MAIN_LOG_FILE = str(logfile)
    handler.close()
    handler.stream = handler._open()


def get_main_filename():
    return MAIN_LOG_FILE


def configure(filename=None, no_heartbeats=False):
    logging.config.dictConfig(CONFIG)
    if filename:
        set_main_filename(filename)

    logging.captureWarnings(True)
    warnings.filterwarnings("default", category=PendingDeprecationWarning)
    warnings.filterwarnings("default", category=DeprecationWarning)
    warnings.filterwarnings("ignore", category=DeprecationWarning, module=".*IPython.*")
    warnings.filterwarnings("ignore", category=DeprecationWarning, module="path")

    logging.debug("="*80)
    logging.debug("Logging configured (path=%s)", filename or LOG_PATH)
    logging.debug("="*80)

def set_level(level):
    logging.root.handlers[1].setLevel(getattr(logging, level))


def get_level():
    return logging.getLevelName(logging.root.handlers[1].level)


def set_verbose():
    set_level("DEBUG")


def reset_log():
    for handler in logging.root.handlers:
        if hasattr(handler, "filename"):
            with open(handler.filename, "w"):
                pass
