var http = require('http');
var util = require('util')
var ref = require('ref');
var ffi = require('ffi');
var url = require('url')
var Struct = require('ref-struct');
var ArrayType = require('ref-array');
var exitHook = require('exit-hook');

// Copied from node's internal/url.js
const searchParamsSymbol = Symbol('query');
function urlToOptions(url) {
  var options = {
    protocol: url.protocol,
    hostname: url.hostname,
    hash: url.hash,
    search: url.search,
    pathname: url.pathname,
    path: `${url.pathname}${url.search}`,
    href: url.href,
    headers: {},
  };
  if (url.port !== '') {
    options.port = Number(url.port);
  }
  if (url.username || url.password) {
    options.auth = `${url.username}:${url.password}`;
  }
  return options;
}

function requestParamsToOptions(options) {
  if (typeof options === 'string') {
    options = url.parse(options);
    if (!options.hostname) {
      throw new errors.Error('ERR_INVALID_DOMAIN_NAME');
    }
    options = urlToOptions(options)
  } else if (options && options[searchParamsSymbol] &&
             options[searchParamsSymbol][searchParamsSymbol]) {
    // url.URL instance
    options = urlToOptions(options);
  } else {
    options = util._extend({}, options);
  }

  return options;
}


 
var stringPtrArray = ArrayType('string');
var charArray = ArrayType(ref.types.char);

// Message id 0 is reserved to mean "not applicable"
var currentMessageId = 1;

function getNextMessageId() {
  var ret = currentMessageId;
  currentMessageId += 1
  return ret
}

var ExternalHeaders = Struct({
  'headerCount' : ref.types.ulong,
  'headerNames' : stringPtrArray,
  'headerValues' : stringPtrArray,
})

var SocketInfo = Struct({
  'address': 'string',
  'port': 'uint'
})

var ExternalRequest = Struct({
  'message_id': 'ulong',
  'remote_message_id': 'ulong',
  'localSocketInfo': SocketInfo,
  'remoteSocketInfo': SocketInfo,
  'method' : 'string',
  'url' : 'string',
  'isHttps': 'ulong',
  'headers': ExternalHeaders,
})

var ExternalResponse = Struct({
  'message_id': 'ulong',
  'remote_message_id': 'ulong',
  'localSocketInfo': SocketInfo,
  'remoteSocketInfo': SocketInfo,
  'remoteInstanceId': 'string',
  'statusCode': 'ulong',
  'headers': ExternalHeaders,
})

var RequestAction = Struct({
  'actions': 'uint',
  'code': 'uint',
  'rejectionMessageMaxSize' : 'uint',
  'rejectionMessage' : 'string'
})

const ADDITIONAL_HEADER_COUNT = 5;
const HEADER_NAME_LENGTH = 50;
const HEADER_VALUE_LENGTH = 300;

var AdditionalHeaders = Struct({ 
  'headerCount' : ref.types.ulong,
  'headerNames' : stringPtrArray,
  'headerValues' : stringPtrArray
})

const lib_api = {
  'OCTARINE_init': ['int', []],
  'OCTARINE_fini': ['void', []],
  'OCTARINE_verifyStructs' : ['bool', ['uint', 'uint', 'uint', 'uint']],
  'OCTARINE_handleResponse': ['void', ['uint', ref.refType(ExternalResponse)]],
  'OCTARINE_handleRequest': ['void', ['uint', ref.refType(ExternalRequest), ref.refType(RequestAction)]],
  'OCTARINE_canSendToHost': ['uint', ['string']],
  'OCTARINE_getAdditionalHeaders': ['void', ['uint32', 'uint32', 'uint32', ref.refType(AdditionalHeaders)]],
}

function load_library() {
  var octarine = ffi.Library('./libagent', lib_api);
  return octarine
}

function installHooks() {
  originalRequest = http.request
  http.request = createRequestHook(originalRequest)

  originalCreateServer = http.createServer
  http.createServer = createCreateServerHook(originalCreateServer)
}

function set_exit_hook() {
  var exitHook = require('exit-hook');
  exitHook(function () {
  console.log('Octarine leaving');
  if (octarine) {
    octarine.OCTARINE_fini()
  }
  });
}

function initialize() {
  if (!octarine) {
    console.log('Octarine was not loaded. Not initializing hooks')
    return
  }

  var rc = octarine.OCTARINE_init()
  if (rc) {
    throw new Error("Error initializing Octarine agent")
  }

  set_exit_hook()
  
  var structureSizesMatch = octarine.OCTARINE_verifyStructs(ExternalRequest.size, RequestAction.size, ExternalResponse.size, AdditionalHeaders.size);
  if (!structureSizesMatch) {
    throw new Error("NodeJS hook and octarine module have mismatching ABI");
  }

  installHooks()
}

octarine = load_library()
initialize()

function socketRemoteInfo(socket) {
  var socketInfo = new SocketInfo();
  socketInfo.address = socket.remoteAddress;
  socketInfo.port = socket.remotePort;
  return socketInfo;
}

function socketLocalInfo(socket) {
  var socketInfo = new SocketInfo();
  socketInfo.address = socket.localAddress;
  socketInfo.port = socket.localPort;
  return socketInfo;  
}

function setSocketInfo(obj, socket) {
  obj.remoteSocketInfo = socketRemoteInfo(socket)
  obj.localSocketInfo = socketLocalInfo(socket)
}

function jsServerRequestToOctarineRequest(req) {
  var externalRequest = new ExternalRequest()

  externalRequest.message_id = getNextMessageId()
  externalRequest.remote_message_id = Number(req.headers["x-octarine-message-id"])
  externalRequest.method = req.method;
  externalRequest.url = req.url;
  setSocketInfo(externalRequest, req.socket)
  headerCount = req.rawHeaders.length / 2;

  externalRequest.headers.headerCount = headerCount
  if (req.connection.encrypted) {
    externalRequest.isHttps = 1
  } else {
    externalRequest.isHttps = 0;
  }

  prepareHeadersForOctarineStruct(externalRequest.headers, req.rawHeaders)

  return externalRequest
}

function flattenHeaders(headers) {
  newHeaders = []
  for (var key in headers) {
    if (headers.hasOwnProperty(key)) {
      newHeaders.push(key);
      newHeaders.push(headers[key])
    }
  }

  return newHeaders
}

function prepareHeadersForOctarineStruct(octarine_headers, js_headers) {
  if (!js_headers) {
    octarine_headers.headerCount = 0
    return
  }

  if (!Array.isArray(js_headers)) {
    js_headers = flattenHeaders(js_headers)
  }

  headerNames = []
  headerValues = []
  var headerCount = js_headers.length / 2
  for (i = 0; i < headerCount; i++) {
    headerNameIndex = i * 2
    headerValueIndex = i * 2 + 1
    headerNames.push(js_headers[headerNameIndex])
    headerValues.push(js_headers[headerValueIndex])
  }

  octarine_headers.headerNames = headerNames
  octarine_headers.headerValues = headerValues
  octarine_headers.headerCount = headerCount

}

function jsClientRequestToOctarineRequest(req, originalHost) {
  var externalRequest = new ExternalRequest()
  req._headers["host"] = originalHost;
  prepareHeadersForOctarineStruct(externalRequest.headers, req._headers)
  console.log(req._headers)
  console.log(externalRequest.headers)
  externalRequest.remote_message_id = 0
  externalRequest.host = req.host
  externalRequest.method = req.method
  externalRequest.url = req.path
  for(var key in req.agent.sockets) {
    socket = req.agent.sockets[key]
    setSocketInfo(externalRequest, socket) // TODO: Figure out how to get the SocketInformation (perhaps use the 'connect' event)
    break
  }

  return externalRequest
}

function responseToOctarineResponse(res) {
  var externalResponse = new ExternalResponse()
  if (res.rawHeaders) {
    var headers = res.rawHeaders
  } else {
    var headers = res.headers
  }

  externalResponse.message_id = res._octarine_message_id
  externalResponse.remote_message_id = res._octarine_remote_message_id
  externalResponse.remoteInstanceId = res._octarine_remote_instance_id
  prepareHeadersForOctarineStruct(externalResponse.headers, headers)
  externalResponse.statusCode = res.statusCode
  return externalResponse
}

function endServerResponseHook() {
  this._orig_end.apply(this, arguments)
  externalResponse = responseToOctarineResponse(this);
  setSocketInfo(externalResponse, this.socket)  
  isIncoming = 0
  octarine.OCTARINE_handleResponse(isIncoming, externalResponse.ref())
}

function createCreateServerHook(originalCreateServer) {
  return function(onRequest) {
    return originalCreateServer.call(http, function(req, res) {
      var externalRequest = jsServerRequestToOctarineRequest(req)
      requestAction = new RequestAction();
      requestAction.rejectionMessageMaxSize = 0;
      res._octarine_message_id = externalRequest.message_id
      res._octarine_remote_message_id = externalRequest.remote_message_id
      res._octarine_remote_instance_id = ""
      if (req.headers.hasOwnProperty("x-octarine-instance-id")) {
        res._octarine_remote_instance_id = req.headers["x-octarine-instance-id"]
      }
      res._orig_end = res.end
      res.end = endServerResponseHook

      isIncoming = 1
      octarine.OCTARINE_handleRequest(isIncoming, externalRequest.ref(), requestAction.ref())

      for (let key in additionalHeaders) {
        let value = additionalHeaders[key];
        res.setHeader(key, value);
      };
      res.setHeader("x-octarine-message-id", `${res._octarine_message_id}`)

      // TODO: Make sure this hardcoded 1 corresponds to Actions.BLOCK on the D side
      if (requestAction.actions & 1) {
        console.log("Rejected");
        res.writeHead(400, {'Content-Type': 'text/plain'});
        res.write("Rejected!");
        res.end();
      } else {
        return onRequest(req, res)
      }
    })
  }
}

// store a reference to the original request function
// override the function
const _MAX_ADDITIONAL_HEADERS = 2
const _MAX_HEADER_NAME = 50
const _MAX_HEADER_VALUE = 500

function prepareAdditionalHeaders() {
  additionalHeaders = new AdditionalHeaders()
  additionalHeaders.headerNames = stringPtrArray(_MAX_ADDITIONAL_HEADERS)
  additionalHeaders.headerValues = stringPtrArray(_MAX_ADDITIONAL_HEADERS)
  for (i = 0; i < _MAX_ADDITIONAL_HEADERS; i++) {
    additionalHeaders.headerNames[i] = charArray(_MAX_HEADER_NAME).ref()
    additionalHeaders.headerValues[i] = charArray(_MAX_HEADER_VALUE).ref()
  }
  return additionalHeaders
}

function getAdditionalHeaders() {
  var additionalHeaders = prepareAdditionalHeaders()
  octarine.OCTARINE_getAdditionalHeaders(_MAX_ADDITIONAL_HEADERS, _MAX_HEADER_NAME, _MAX_HEADER_VALUE, additionalHeaders.ref())
  jsAdditionalHeaders = {}
  for (i = 0; i < additionalHeaders.headerCount; i++) {
    jsAdditionalHeaders[additionalHeaders.headerNames[i]] = additionalHeaders.headerValues[i]
  }

  return jsAdditionalHeaders;
}

additionalHeaders = getAdditionalHeaders();

function createRequestHook(originalRequest) {
  return function(options, callback) {
    options = requestParamsToOptions(options)
    options.headers = util._extend(additionalHeaders, options.headers);
    var octarine_message_id = getNextMessageId()
    options.headers["x-octarine-message-id"] = `${octarine_message_id}`

    function hookedCallback(response) {
      response._octarine_message_id = octarine_message_id
      response._octarine_remote_message_id = 0
      var externalResponse = responseToOctarineResponse(response)
      externalResponse.remote_message_id = 0
      setSocketInfo(externalResponse, response.connection)
      isIncoming = 1
      octarine.OCTARINE_handleResponse(isIncoming, externalResponse.ref())
      if (callback) {
        callback(response)      
      }
    }

    var originalHost = options["host"] || options["hostname"]
    var canSend = octarine.OCTARINE_canSendToHost(originalHost)
    if (!canSend) {
      options["hostname"] = "localhost"
      options["host"] = "localhost"
      options["port"] = 56012
      console.log("Rejected outgoing message")
    }

    var req = originalRequest(options, hookedCallback)
    var octarineRequest = jsClientRequestToOctarineRequest(req, originalHost)
    octarineRequest.isHttps = 0;
    octarineRequest.message_id = octarine_message_id
    var requestAction = new RequestAction();
    requestAction.rejectionMessageMaxSize = 0;
    isIncoming = 0;
    octarine.OCTARINE_handleRequest(isIncoming, octarineRequest.ref(), requestAction.ref())

    return req
  }
}
